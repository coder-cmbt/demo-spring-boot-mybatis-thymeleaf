package com.cmbt.demo.model;

public enum Sex {
    MALE, FEMALE, SECRET
}